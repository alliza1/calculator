function loadcalculator() {
    document.getElementById('newsFrame').src = "calculator.html";
}
function loadChange() {
    document.getElementById('newsFrame').src = "color_changer.html";
}

